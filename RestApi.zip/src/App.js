const express = require ("express");
require ("./db/connection");
const student = require ("./Models/student");
const app = express();


const port = process.env.PORT ||5000;
app.use(express.json());

app.post("/student",(req,res)=>{
    console.log(req.body);
    const user = new student(req.body)
  user.save().then(()=>{
    req.status(201).send(user);

  }).catch ((e)=>{
    res.status(400).send(e)  
})
})
app.post("/student",async(req,res)=>{

    try{
        const user = new student(req.body);
        const createuser =await user.save();
        res.status(201).send(createuser); 

    }catch(e){
        res.status(400).send(e);

    }
  
    res.status(400).send(e)  
})
//Read the data of the Registered student



app.get("/student",async(req,res)=>{
  try{
    const studentdata = await student.find();
    res.send(studentdata);

  }catch(e){
    res.send(e);

  }
})

//get the indivisual student data using id 

app.get("/student/:name",async(req,res)=>{
    try{
        const_id =req.params;
       const studentdata = await student.findById(_id);

        if(!studentdata){
            return res.status(404).send();

        }else{
            res.send(studentdata);
        }
    }catch{
     res.status(500).send(e);
    }
})
//update the student by it id

app.patch("/students/:id",async(req,res)=>{
    try{
        const_id =req.params.id;
        const updatestudent = await student.findByIdAndUpdate(_id,req.body,{
            new:true
        });
        res.send(updatestudent);
    }catch(e){
        res.status(400).send(e);

    }
})

//delete the student by it id
app.delete("/students/:id",async(req,res)=>{
    try{
        const deletestudent = await student.findByIdAndDelete(res.params.id);
        if(!res.params.id){
            return res.status(404).send();
        }
            res.send(deletestudent);
 
    }catch(e){
        res.status(500).send(e);
    }

})


//create a new router

const router = new express.Router();


//we need to define the router

router.get("/thapa",(req,res)=>{
    res.send("hello users")
}); 

//Login check

app.post("/login", async (req, res) => {
    try {
      const email = req.body.email;
      const password = req.body.password;
  
      const useremail = await Register.findOne({ email: email });
  
      const isMatch = await bcrypt.compare(password, useremail.password);
  
      const token = await useremail.generateAuthtoken();
      console.log("the token part " + token);
  
      res.cookie("jwt", token, {
        expires: new Date(Date.now() + 6000000),
        httpOnly: true,
        // secure:true
      });
  
      if (isMatch) {
        res.status(201).redirect("product");
      } else {
        res.send("valid Login Details");
      }
    } catch (error) {
      res.status(400).send("Invalid Login Details");
    }
  });

  //create a new user in our database
app.post("/Regstration",upload, async (req, res) => {
    try {
      const password = req.body.password;
      const cpassword = req.body.confirmpassword;
  
      if (password === cpassword) {
        const registeremp = new Register({
          firstname: req.body.firstname,
          lastname: req.body.lastname,
          phone: req.body.phone,
          age: req.body.age,
          email: req.body.email,
          password: password,
          confirmpassword: cpassword,
          gender: req.body.gender,
          image:req.file.filename,
  
        });
        var filefild = req.file
  
        console.log("the success part" + registeremp);
  
        const token = await registeremp.generateAuthtoken();
        console.log("the token part" + token);
  
        res.cookie("jwt", token, {
          expires: new Date(Date.now() + 6000000),
          httpOnly: true,
        });
  
        const registered = await registeremp.save();
        console.log("the page part" + registered);
  
        res.status(201).redirect("product");
      } else {
        res.send("password are not match");
      }
    } catch (error) {
      res.status(400).send(error);
    }
  });
  



//generating token
employeeShema.methods.generateAuthtoken = async function () {
    try {
        console.log(this._id)
        const token = jwt.sign({ _id: this._id.toString() }, process.env.SECRET_KEY);
        this.tokens = this.tokens.concat({ token: token })
        await this.save();
        return token;
    } catch (error) {
        res.send("the part error" + error)
        console.log("the part error" + error)


    }
}

//converting password into hash
employeeShema.pre("save", async function (next) {

    if (this.isModified("password")) {
        // const passwordHash = await bcrypt.hash(password,10);

        this.password = await bcrypt.hash(this.password, 10);

        this.confirmpassword = await bcrypt.hash(this.password, 10);
    }

    next();
});

//Handle to jsonwebtoken
const jwt = require("jsonwebtoken");
// const orderModel = require("./models/ordermodel");

const createToken = async () => {
  console.log(process.env.SECRET_KEY,"key");
  const token = await jwt.sign(
    { _id: "6305a65642d4eaf6cfdb9d12"},
    process.env.SECRET_KEY,
    {
      expiresIn: "5 second",
    }
  );
  //    console.log(token)
// createToken(); 
  const userVer = await jwt.verify(token, process.env.SECRET_KEY);
  //    console.log(userVer)
};



app.listen(port,()=>{
    console.log(`connection is setup at ${port}`);
})