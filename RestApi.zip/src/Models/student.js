const mongoose = require ("mongoose");
const validator = require("validator");


//schema
const studentschema =new mongoose.Schema({
    name:{
        type:String,
        required:true,
        minlength:3
    },
    
        email:{
            type:String,
            require:true,
            unique:[true, "email is alrady present"],
            validate(value){
                if(!validator.isemail(value)){
                    throw new Error("invalid email")
                }
            }
        },
        phone:{
            type:Number,
            min:10,
            max:10,
            required:true,
            unique:true
        }
        //we will create a new connection
    // const student = new mongoose module ("student",studentschema)

    //     module.exports =student;
    
})