const mongoose = require ("mongoose");
const validator = require("validator");


//connection create a new database
 mongoose.connect("mongodb://localhost:27017/ttchanell",{ 
  // usenewUrlparser:true, 
// useUnifindTopology:true,
// useCreateIndex:true
})
  .then(()=>console.log("connection successfull......"))
.catch((err)=>
console.log(err));

// // connection creation
// const playlist = new mongoose.model("playlist", playlistSchema);


//create a document or insert
const createdocument = async()=>{
    try{
        const reactplaylist = new playlist({
            name: "React js",
            ctype: "frontend",
            video:50,
            Author:"thapa",
           active:"true"
        })
        
        const mongoplaylist = new playlist({
            name: "mongo js",
            ctype: "frontend",
            video:50,
            Author:"thapa",
           active:"true"
        })

        const jsplaylist = new playlist({
            name: "javascript js",
            ctype: "frontend",
            video:50,
            Author:"thapa",
           active:"true"
        })

        const backendplaylist = new playlist({
            name: "Backend js",
            ctype: "frontend",
            video:50,
            Author:"thapa",
           active:"true"
        })

        
        const result = await playlist.insertmany([reactplaylist,mongoplaylist,jsplaylist,backendplaylist]);
        console.log(result);
    }catch(err){
        console.log(err);

    }
    }



  
//createdocument();
try{
    const getDocument =async () =>{
        const result = await  playlist.find({$and:[{ctype:"Backend"},
    {author:"thapa"}]})    
        .select({name:1})
        .limit(1);
        console.log(result);
}

}catch(err){
    console.log(err);

}

//update document
const updateDocument = async(_id)=>{
    try{
        const result =await playlist.findByIdAndupdate({_id},{
            $set :{
                name:"javascript"
            }
            },{
                usefindAndModify:false
    
        })
}catch(err){
console.log(err);
    }
  
}

//delete document
const deleteDocument = async()=>{
    try{
        const result =await playlist.findByIdAndDelete({_id});
          
    console.log(result);
}catch(err){
console.log(err);
    }
  
}




// updateDocument("5f9b80cebedb3b411c22fabb");
